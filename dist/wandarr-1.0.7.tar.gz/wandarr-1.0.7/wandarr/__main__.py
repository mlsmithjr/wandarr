from . import transcode


def main():
    transcode.main()
