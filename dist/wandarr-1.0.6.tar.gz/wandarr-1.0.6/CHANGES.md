## Changes

#### 01/29/2024 v1.0.6
* Minor parsing bug fix for multiple audio and subtitle tracks.  Videos previously encoded are not affected.
* Added -vq (video quality) option to override default quality in the template, reducing the number of
* templates you have to define if the difference is only the quality.

#### 11/26/2023 v1.0.5
* Added -l (local-only) mode. Skips detection and use of remove machines.
* Internal refactoring to make the code more readible.
* Bug fixes to agent-based host management
* Reduce redundant pings to hosts for awake-checks

#### 10/20/2023 v1.0.4
* Code refactoring cleanup
* Misc small bug fixes related to parsing media technical details

#### 10/16/2023 v1.0.3
* Continue to make small usability tweaks
* Switch to using ffprobe for primary tech details, ffmpeg secondary
* Fixed some parsing issues when certain information isn't present

#### 10/13/2023 v1.0.2
* better error reporting for some activities
* refine the progress bar to provide more information

#### 10/5/2023 v1.0.1 - Initial working version
