
from wandarr import transcode

#
# stub for running wandarr as a package while developing and testing.
#

transcode.start()
